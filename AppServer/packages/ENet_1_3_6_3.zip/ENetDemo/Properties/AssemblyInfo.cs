﻿using System.Reflection;

[assembly: AssemblyTitle("ENet Demo")]
[assembly: AssemblyProduct("ENet for C#")]
[assembly: AssemblyCopyright("Copyright © 2011 James F. Bellinger <jfb@zer7.com>")]
[assembly: AssemblyVersion("1.3.6.3")]
[assembly: AssemblyFileVersion("1.3.6.3")]

