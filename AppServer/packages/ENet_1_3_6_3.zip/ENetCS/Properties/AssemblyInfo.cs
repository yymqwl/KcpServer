﻿using System;
using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("ENet")]
[assembly: AssemblyProduct("ENet for C#")]
[assembly: AssemblyCopyright("Copyright © 2011-2013 James F. Bellinger <jfb@zer7.com>")]
[assembly: AssemblyVersion("1.3.6.3")]
[assembly: AssemblyFileVersion("1.3.6.3")]
[assembly: ComVisible(false)]
[assembly: CLSCompliant(false)]